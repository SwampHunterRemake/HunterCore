@NullMarked
@Environment(EnvType.CLIENT)
package com.mojang.renderpearl.frontend;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.NullMarked;
